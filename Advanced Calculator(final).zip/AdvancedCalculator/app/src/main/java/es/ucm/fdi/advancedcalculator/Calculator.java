package es.ucm.fdi.advancedcalculator;

public class Calculator {

    public double sum(double a, double b) {
        return a + b;
    }

}

