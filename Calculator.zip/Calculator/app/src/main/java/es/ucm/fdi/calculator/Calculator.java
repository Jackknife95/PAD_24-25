package es.ucm.fdi.calculator;

public class Calculator {

    public double sum(double a, double b) {
        return a + b;
    }

}
