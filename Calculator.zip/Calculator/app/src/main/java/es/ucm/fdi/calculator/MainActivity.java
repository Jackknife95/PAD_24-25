package es.ucm.fdi.calculator;

import android.app.Notification;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {

    // Variables miembro de la clase
    private Calculator calculadora;
    private TextInputEditText editText1;
    private TextInputEditText editText2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicialización de las variables
        calculadora = new Calculator();
        editText1 = findViewById(R.id.numero1);
        editText2 = findViewById(R.id.numero2);

        Button boton = findViewById(R.id.boton);
        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addXandY();  // Llamar al método addXandY
            }
        });
    }

    // Método addXandY
    private void addXandY() {
        // Obtener los valores de los EditText como String
        String value1 = editText1.getText().toString();
        String value2 = editText2.getText().toString();

        // Asegurarse de que no estén vacíos
        if (!value1.isEmpty() && !value2.isEmpty()) {
            double x = Double.parseDouble(value1);
            double y = Double.parseDouble(value2);

            double result = calculadora.sum(x, y);

            Intent intent = new Intent(MainActivity.this, CalculatorResultActivity.class);

            intent.putExtra("RESULTADO", result);

            startActivity(intent);
        } else {
            // Manejar el caso en que uno de los campos esté vacío (por ejemplo, mostrar un mensaje)
            Toast.makeText(MainActivity.this, "Por favor, ingrese ambos números", Toast.LENGTH_SHORT).show();
        }
    }
}
